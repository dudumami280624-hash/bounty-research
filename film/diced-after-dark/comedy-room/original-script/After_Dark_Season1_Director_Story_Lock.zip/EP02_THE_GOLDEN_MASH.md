# THE GOLDEN MASH / 黄金薯泥

FORMAT: 9:16 | 60s | 10 shots × 6s | American English | original adult absurdist comedy

Opening hook must be readable visually in 0–2 seconds. Dialogues are target lines, not a claim that speech synthesis fits without rehearsal.

| Time | Picture / action | English line | Story function |
|---|---|---|---|
| 0–6 | 0–2秒：门口一排顾客举着同款免费券，老板把自己的粗金链当成排队绳，被顾客拉得站不稳。 | POTATO: That's Italian gold! | 直接兑现EP01万人承诺 |
| 6–12 | Basil把真实成本表递给老板，老板用金色贴纸盖住亏损数字。 | BASIL: Stickers don't fix math. | 冲突：利润与面子 |
| 12–18 | 老板决定只提供一粒薯泥，Pickle用镊子端上比豌豆还小的份量。 | POTATO: Luxury is about restraint. | 荒诞视觉：极小份量 |
| 18–24 | 顾客拿出放大镜；Cherry拍摄“全球最小免费午餐”。 | CHERRY: I can barely see the scandal. | 网红制造舆论 |
| 24–30 | Lemon展示海报原文“one full serving”，老板愣住。 | LEMON: Your poster says full serving. | 规则回收，限制钻空子 |
| 30–36 | Basil提出用一辆移动餐车提供真正份量，条件是保留自己的名字和配方。 | BASIL: My recipe. My credit. | 主厨主动争取权益 |
| 36–42 | 老板为了救场签了原创授权纸，连看都没看。 | POTATO: Fine. Make me look generous. | 老板的选择制造后果 |
| 42–48 | Cherry发现授权纸里写着“主厨独立品牌”，把镜头对准Basil。 | CHERRY: Wait. He just gave you a brand. | 网红见证权力转移 |
| 48–54 | Pickle推餐车出门，却将印着老板头像的广告板装反，露出Basil名字。 | PICKLE: Good news. The sign fits. | 视觉喜剧，促成Basil出名 |
| 54–60 | 第一位顾客尝到Basil的薯泥，举起满分牌；老板伸手抢牌，却发现写的是“BASIL”。 | POTATO: Who the hell is Basil?! | 结尾：老板丢掉声望 |

## Directing notes
One visual gag per shot; reactions before explanations. Do not show tobacco use, weapon threats, real law enforcement credentials, real platform UI, or recognizable third-party marks. Generate legible graphics in post-production, not in the AI image. Characters remain visually LOCKED.
