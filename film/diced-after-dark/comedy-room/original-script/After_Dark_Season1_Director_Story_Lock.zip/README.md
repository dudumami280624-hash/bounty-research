# Season 1 Director's Story Lock
Four episodes × 10 shots × 6 seconds = 240-second scripted season.
The five character designs are locked. This is an **internal story/creative lock**; not a guarantee of TikTok approval, viewer retention, trademark clearance, or final cut timing.
Files: four bilingual shot scripts (English dialogue, Chinese action direction), story bible, audit, pre-production checklist.
