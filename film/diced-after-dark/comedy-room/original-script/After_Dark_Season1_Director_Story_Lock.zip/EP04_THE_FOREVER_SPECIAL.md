# THE FOREVER SPECIAL / 终身特供

FORMAT: 9:16 | 60s | 10 shots × 6s | American English | original adult absurdist comedy

Opening hook must be readable visually in 0–2 seconds. Dialogues are target lines, not a claim that speech synthesis fits without rehearsal.

| Time | Picture / action | English line | Story function |
|---|---|---|---|
| 0–6 | 0–2秒：餐厅门口顾客挥舞终身免费券；老板的金链再次被当作排队绳，脖子上的空链扣晃荡。 | POTATO: Stop using me as furniture! | EP01海报与EP03条款兑现 |
| 6–12 | Lemon把两张纸摆在桌上：老板个人免费承诺；Basil独立品牌授权。 | LEMON: His business. Your promise. | 权利义务区分 |
| 12–18 | 老板想卖“免费餐会员卡”，Cherry立刻把收费价目表推到镜头前。 | CHERRY: Charging for free? Bold. | 网红抓现行，非诈骗教学 |
| 18–24 | Basil拒绝替老板承担终身免费订单，继续给正常付费顾客做餐。 | BASIL: I don't work for your ego. | 主厨完成独立 |
| 24–30 | Pickle端着一整锅薯泥来帮老板，却把锅放到“VIP仅供拍照”展示台。 | PICKLE: Presentation matters. | 视觉喜剧 |
| 30–36 | Lemon指出承诺限前100名：Pickle把人数写错，但原始签名海报是100。 | LEMON: The signed original says one hundred. | 合理收束人数，不无限债务 |
| 36–42 | 老板松口气，正准备庆祝；Lemon补充：100人每人终身一份，仍得他自己负责。 | LEMON: A hundred people. For life. | 新一层反转 |
| 42–48 | 老板不得不戴上围裙，手工压薯泥；Basil从旁经过，纠正他的姿势。 | BASIL: You're holding it upside down. | 权力倒置与角色笑点 |
| 48–54 | Cherry镜头对准老板，屏幕上原创标题“THE PEOPLE'S POTATO”；老板竟开始享受掌声。 | POTATO: Maybe I am the people's potato. | 老板学到错误的教训 |
| 54–60 | Pickle递来新报名表“全市最谦虚老板大赛”；老板抢笔签字，Lemon无声扶额。 | PICKLE: I signed you up for humility. | 季终笑点与新季引线 |

## Directing notes
One visual gag per shot; reactions before explanations. Do not show tobacco use, weapon threats, real law enforcement credentials, real platform UI, or recognizable third-party marks. Generate legible graphics in post-production, not in the AI image. Characters remain visually LOCKED.
