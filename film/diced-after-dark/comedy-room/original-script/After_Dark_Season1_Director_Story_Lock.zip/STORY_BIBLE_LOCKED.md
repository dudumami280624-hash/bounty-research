# FIRST SEASON — DIRECTOR'S STORY BIBLE (STORY LOCK)
Working title: DICED AFTER DARK (NOT trademark-cleared; replaceable).
Format: four 60-second vertical episodes, ten 6-second beats per episode. English spoken dialogue, Chinese action notes.

## Creative thesis
A self-obsessed potato mob-style restaurant owner gets a one-star review, makes a wildly irresponsible free-food promise to save face, and accidentally makes his own chef a star. The humor comes from adult ego, business vanity, contract consequences, public humiliation, and absurd visual staging, NOT gore, violence, or generic mysteries.

## Characters — visual designs locked, DO NOT redesign
Basil Blade: tall basil-headed chef, lean, tattooed, dark apron, meticulous and ambitious. Wants creative ownership.
Big Potato: stout potato-headed boss, fedora, pinstripe suit, thick gold chains, rings, large UNLIT cigar as a non-emphasized costume prop. Wants adoration, hates criticism.
Cherry Lux: glamorous cherry-headed creator, red fitted outfit, faux fur, original vine tattoos. Wants attention and sponsor income.
Pickle Frank: bulky green pickle-headed fixer, beanie, sunglasses, sleeveless vest, original abstract tattoos. Wants approval; overly literal and physically competent.
Lemon Vera: lemon-headed private investigator and contract consultant, glasses, beige trench, fictional generic paper credentials only. Wants to make people accountable, enjoys precision.
No repeated spade motif, real logos, gang badges, real police/FBI identifiers.

## Story and prop continuity
EP01 one-star review motivates boss. Signed original offer is FREE MASH FOR LIFE — FIRST 100; Pickle's oversized public display erroneously says 10,000. Cherry publishes the mistaken display. Lemon sees signed original. Basil demands credit.
EP02 crowd shows up because of EP01 public offer. Potato tries tiny portions, but full serving promise stops it. He signs independent-brand licensing terms without reading. Basil's food wins acclaim, boss loses identity.
EP03 Basil's name dominates billboard due to EP02. Pickle physically relocates movable billboard into doorway; Basil can serve outside under signed license. Back of poster reveals lifetime condition.
EP04 Lemon compares original signed FIRST 100 with Pickle's incorrect 10,000 sign; only 100 valid lifetime offers in story's fictional contractual framework. Potato personally serves 100 lifetime customers, Basil remains independent, Cherry profits from coverage, Pickle enters boss into next contest.
Legal note: this is fictional contract logic, not real legal advice or a statement about enforceability of advertisements.

## Style
American absurdist adult comedy with high-stakes noir framing, petty motivations and deadpan delivery; hyperreal cinematic 3D, cool neutral/blue lighting, no warm fairy-tale grading. No violence, blood, threats, sexual content, criminal instructions. Props such as kitchen knives only as ordinary tools, not threatening shots. No real UI or brand marks.

## Production
Keep 5 character master designs exactly as approved. One dominant action per 6s shot. Graphics/posters and dialogue subtitles in post. No need to depict 10,000 individual people; close shots of tickets, crowd edges, sound and 2–4 extras. Visual punchline should read without sound. Voice actor rehearsal and animatic required before locking shot timings.
