# THE ONE-STAR WAR / 一星战争

FORMAT: 9:16 | 60s | 10 shots × 6s | American English | original adult absurdist comedy

Opening hook must be readable visually in 0–2 seconds. Dialogues are target lines, not a claim that speech synthesis fits without rehearsal.

| Time | Picture / action | English line | Story function |
|---|---|---|---|
| 0–6 | 0–2秒：土豆老板看到巨幅电子广告牌：他的餐厅评分1.0；他气得把写着“BEST BOSS”的小奖杯倒扣在桌上。 | POTATO: One star? I own the building! | 评分羞辱→自尊受损 |
| 6–12 | 老板把一份原创纸质“全民免费薯泥日”海报拍在桌上；Basil盯着免费两个字。 | BASIL: You can't afford free. | 老板为面子做承诺 |
| 12–18 | Cherry偷偷把海报拍成短视频，特写“FREE MASH FOR LIFE—FIRST 100”。 | CHERRY: The internet loves a bad decision. | 网红为了流量公开承诺 |
| 18–24 | Pickle自告奋勇负责数字牌，认真把“100”写成“10,000”。 | PICKLE: I made it bigger. You're welcome. | 错误行动放大人数 |
| 24–30 | Lemon作为受雇合同顾问指向海报右下角：老板签名已经盖上。 | LEMON: That's a promise with your signature. | 合同后果成立 |
| 30–36 | Potato看见10,000，反而摆出胜利姿势，对着空镜头练习挥手。 | POTATO: Ten thousand fans. Finally. | 自恋使他不纠错 |
| 36–42 | Basil端出一小碗真正美味的薯泥，老板却用金色包装纸盖住它。 | BASIL: You're selling foil, not food. | 主厨价值观冲突 |
| 42–48 | Cherry的视频播放数字飞涨；她露出得意表情，暗中开启“赞助商询价”便签。 | CHERRY: I'm monetizing the meltdown. | 网红逐利有后果 |
| 48–54 | 门外第一位顾客举着免费券；Pickle一本正经给他发号码“0001”。 | PICKLE: Only nine thousand nine hundred ninety-nine left. | 队列灾难具体化 |
| 54–60 | 镜头切到街角：排队人群一直延伸到拐角；Lemon拿起合同。 | LEMON: You just made tomorrow everyone's problem. | 下集承诺：明天必须兑现 |

## Directing notes
One visual gag per shot; reactions before explanations. Do not show tobacco use, weapon threats, real law enforcement credentials, real platform UI, or recognizable third-party marks. Generate legible graphics in post-production, not in the AI image. Characters remain visually LOCKED.
