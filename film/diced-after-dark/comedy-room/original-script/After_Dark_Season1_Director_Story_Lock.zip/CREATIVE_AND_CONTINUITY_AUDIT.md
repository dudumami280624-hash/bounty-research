# Director-level creative review — Season 1
## Editorial status: STORY LOCK (internal), not platform-certified
Four episodes, 40 scripted shots, 240 seconds planned. Five character designs locked separately. Title remains provisional.

## Gate 1: 0–2 second hook / on-screen payoff
EP01: one-star humiliation → boss's signed offer → line of claimants. PASS (text graphics need post).
EP02: boss's chain used as queue barrier → portion scam → signed license → Basil wins reputation. PASS.
EP03: Basil billboard eclipses boss → billboard moved → outside cart → lifetime clause. PASS.
EP04: free-ticket mob + chain gag → first-100 correction → boss's permanent obligation → humility contest. PASS.
No hook is an unrelated teaser; each is causally grounded in preceding episode and paid off.

## Gate 2: causality and motivation
Potato: one-star wounded pride → overpromises → signs licensing without reading → becomes free-food laborer.
Basil: exploited employee → requests rights → wins own brand → runs independent cart.
Cherry: opportunistic viral coverage → exposes excess → sponsor angle → public humiliation coverage.
Pickle: tries to impress → wrong number → moves billboard → accidental new contest.
Lemon: signed poster evidence → full-serving rule → independent-license reading → limits claimants to first 100.
PASS for fictional story logic. Advertising-contract enforceability is not a real-world legal claim.

## Gate 3: comedy variety
Visual scale gag (one-star ad), business satire (gold-plated mash), physically absurd chain-as-barrier, microscopic portion, giant billboard blocking door, empty VIP zone, boss serving his own lifetime freebies. Distinct recurring chain gag intentional bookend. PASS editorially; comedic effectiveness untested with U.S. audience.

## Gate 4: production feasibility
10 beats per episode; 6s target each. 1 main action/shot. Spoken lines are mostly brief; a few can be cut or split after voice rehearsal. Posters, numbers, legal clauses, UI and subtitles must be added in post, not left to generative text. CROWD limited to extras + compositing. CONDITIONAL PASS pending animatic and voice timing.

## Gate 5: risk screening
No violence, injury, weapon threat, sexual content, real police insignia, real platform UI, or criminal methods in script. Large cigar remains an unlit non-focused costume prop; remove if platform or generator flags it. Logos, tattoos, signs, music, fonts, likenesses, character title need independent rights review. INTERNAL PRE-SCREEN ONLY; TikTok may still limit content or distribution.

## Remaining honest uncertainties
Not tested against real American audience retention; no guarantee of For You eligibility or commercial clearance; no rendered shots or audio audited. Director's story/creative/continuity text gates passed, while production release remains gated on animatic, asset and platform checks.
