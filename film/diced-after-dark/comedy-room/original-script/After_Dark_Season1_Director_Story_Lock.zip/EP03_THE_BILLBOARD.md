# THE BILLBOARD / 广告牌政变

FORMAT: 9:16 | 60s | 10 shots × 6s | American English | original adult absurdist comedy

Opening hook must be readable visually in 0–2 seconds. Dialogues are target lines, not a claim that speech synthesis fits without rehearsal.

| Time | Picture / action | English line | Story function |
|---|---|---|---|
| 0–6 | 0–2秒：巨幅Basil广告牌遮住老板的餐厅招牌，老板踮脚也看不到自己名字。 | POTATO: I'm being replaced by a leaf! | 兑现EP02主厨走红 |
| 6–12 | Cherry向老板展示她签下的原创品牌合作意向书：只认Basil的名字。 | CHERRY: Sponsors want the chef, not the chair. | 网红改变阵营 |
| 12–18 | 老板命令Pickle“把那块牌子弄走”；Pickle把整块可移动广告牌推进餐厅门口。 | PICKLE: It's off the sidewalk. | 误执行但结果新颖 |
| 18–24 | 广告牌正好堵住餐厅入口；老板和顾客隔着牌子互相看。 | POTATO: You blocked the customers! | 物理灾难升级 |
| 24–30 | Lemon翻出老板在EP02签署的授权纸：Basil可以在外面独立卖菜。 | LEMON: You signed the independence clause. | 因果回收 |
| 30–36 | Basil在门外摆好小餐车，顾客自然排到他的窗口。 | BASIL: Kitchen's open. Ego's closed. | 主厨主动经营 |
| 36–42 | 老板在餐厅里架起“VIP体验”红绳，结果没有一个顾客进得来。 | POTATO: This is exclusivity. | 阶级讽刺视觉笑点 |
| 42–48 | Cherry把老板空无一人的VIP区与Basil长队做分屏，笑着收起赞助意向书。 | CHERRY: Two businesses. One customer line. | 网红镜头推动传播 |
| 48–54 | Pickle想帮忙挪开广告牌，发现背面印着老板签署的“终身免费薯泥”小字。 | PICKLE: Boss... there's more writing. | 新后果由旧海报延伸 |
| 54–60 | Lemon把海报和签名并排，指向“FOR LIFE”；老板慢慢坐进空VIP椅。 | LEMON: You promised free mash for life. | 下集必须处理的合同危机 |

## Directing notes
One visual gag per shot; reactions before explanations. Do not show tobacco use, weapon threats, real law enforcement credentials, real platform UI, or recognizable third-party marks. Generate legible graphics in post-production, not in the AI image. Characters remain visually LOCKED.
